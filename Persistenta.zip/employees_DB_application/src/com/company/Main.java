package com.company;

import javax.swing.plaf.nimbus.State;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Queue;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        showMenu();

        Scanner scan = new Scanner(System.in);
        int optiune = Integer.parseInt(scan.nextLine());


        while (optiune !=7){
            try{
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con= DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/employees","root","P0rt013!@#$");
                //Afisare meniu

                if (optiune==1){
                    System.out.println("Afisarea angajatilor.");
                    Statement stmt=con.createStatement();
                    ResultSet rs=stmt.executeQuery("select * from employees");
                    while(rs.next())
                        System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getInt(4)+"  "+rs.getInt(5));
                    con.close();
                } else if (optiune==2){
                    System.out.println("Introducerea angajatilor.");
                    System.out.println("Introduceti prenumele.");
                    String prenume = scan.nextLine();
                    System.out.println("Introduceti numele.");
                    String nume = scan.nextLine();
                    System.out.println("Introduceti varsta.");
                    int varsta = Integer.parseInt(scan.nextLine());
                    System.out.println("Introduceti salariul.");
                    int salariul = Integer.parseInt(scan.nextLine());

                    Statement stmt = con.createStatement();

                    String query1 = "INSERT INTO employees (first_name, last_name, age, salary)" + "VALUES ('"+ prenume + "','"+ nume + "','"+ varsta + "', '"+ salariul + "');";
                    System.out.println(query1);
                    stmt.executeUpdate(query1);
                    con.close();

                } else if (optiune==3){
                    System.out.println("Schimbarea datelor despre angajati.");
                    System.out.println("Introduceti ID-ul angajatului pentru a efectua modificarile.");
                    int modificare = Integer.parseInt(scan.nextLine());
                    Statement stmt = con.createStatement();
                    String query2 = "SELECT * FROM employees WHERE ID = " + modificare;
                    ResultSet rs = stmt.executeQuery(query2);
                    Boolean exista = false;
                    while (rs.next()){
                        exista = true;
                        System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getInt(4)+"  "+rs.getInt(5));
                    }
                    if (exista == true){
                        System.out.println("Angajatul exista in baza de date.");
                        System.out.println("Introduceti prenumele.");
                        String prenume = scan.nextLine();
                        System.out.println("Introduceti numele.");
                        String nume = scan.nextLine();
                        System.out.println("Introduceti varsta.");
                        int varsta = Integer.parseInt(scan.nextLine());
                        System.out.println("Introduceti salariul.");
                        int salariul = Integer.parseInt(scan.nextLine());
                        String query3 = "update employees set last_name = '"+nume+"',first_name = '"+prenume+"' age = '"+varsta+"' salary = '"+salariul+"' where id =" + modificare;
                        System.out.println(query3);
                        stmt.executeUpdate("update employees set last_name = '"+nume+"',first_name = '"+prenume+"' ,age = '"+varsta+"' ,salary = '"+salariul+"' where id =" + modificare);


                    } else {System.out.println("Angajatul nu exista in baza de date.");}

                } else if (optiune==4){
                    System.out.println("Stergerea unui angajat din baza de date.");
                    System.out.println("Introduceti ID-ul pe care doriti sa-l stergeti");
                    int stergere = Integer.parseInt(scan.nextLine());
                    Statement stmt = con.createStatement();

                    int result = stmt.executeUpdate("delete from employees where id =" + stergere);
                    System.out.println(result);
                    if (result == 1){
                        System.out.println("Angajatul a fost sters.");
                    } else {System.out.println("Angajatul nu a fost sters");};

                } else if (optiune==5){
                    System.out.println("Afisarea selectiva a angajatilor.");
                    System.out.println("Introduceti varsta dorita.");
                    int varsta = Integer.parseInt(scan.nextLine());
                    Statement stm = con.createStatement();
                    String query4 = "SELECT * FROM employees WHERE age > " + varsta;
                    ResultSet rs = stm.executeQuery(query4);
                    while(rs.next())
                        System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getInt(4)+"  "+rs.getInt(5));
                    con.close();

                } else if(optiune==6){
                    System.out.println("Introduceti ID-ul angajatului pe care il cautati.");
                    int id = Integer.parseInt(scan.nextLine());
                    Statement stm = con.createStatement();
                    String query5 = "SELECT * FROM employees WHERE id = " + id;
                    ResultSet rs = stm.executeQuery(query5);
                    while(rs.next())
                        System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getInt(4)+"  "+rs.getInt(5));
                    con.close();
                }

            }catch(Exception e){ e.printStackTrace();}
            showMenu();
            optiune = Integer.parseInt(scan.nextLine());
        }

    }
    public static void showMenu(){
        System.out.println("1. Afisarea angajatilor.");
        System.out.println("2. Introducerea angajatilor.");
        System.out.println("3. Schimbarea datelor despre angajati.");
        System.out.println("4. Stergerea unui angajat din baza de date.");
        System.out.println("5. Afisarea selectiva a angajatilor.");
        System.out.println("6. Afisarea angajatului dupa ID.");
        System.out.println("7. EXIT Application.");
    }
}
